// using System;
// using System.Collections.Generic;
// using System.Linq;
// using System.Threading.Tasks;
// using MySql.Data.MySqlClient;
// using System.Text.Json;
// using System.Net;
// using System.Net.Mail;

// namespace COMMON_PROJECT_STRUCTURE_API.services
// {
//     public class Authentication
//     {
//         private readonly dbServices ds = new dbServices();
//         private readonly Dictionary<string, int> otpStorage = new Dictionary<string, int>();

//         public async Task<responseData> SignUp(requestData rData)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 var email = rData.addInfo["EMAIL"].ToString();
//                 var password = rData.addInfo["PASSWORD"].ToString();

//                 // Check if the email already exists
//                 var query = @"SELECT * FROM mydb.signup WHERE EMAIL=@EMAIL";
//                 MySqlParameter[] myParam = new MySqlParameter[]
//                 {
//                     new MySqlParameter("@EMAIL", email)
//                 };
//                 var dbData = ds.executeSQL(query, myParam);
//                 if (dbData[0].Any())
//                 {
//                     resData.rData["rMessage"] = "Email already exists";
//                 }
//                 else
//                 {
//                     // Insert new user
//                     var insertQuery = @"INSERT INTO mydb.signup (EMAIL, PASSWORD) VALUES (@EMAIL, @PASSWORD)";
//                     MySqlParameter[] insertParams = new MySqlParameter[]
//                     {
//                         new MySqlParameter("@EMAIL", email),
//                         new MySqlParameter("@PASSWORD", password)
//                     };
//                     var insertResult = ds.executeSQL(insertQuery, insertParams);
//                     resData.rData["rMessage"] = "Signup Successful";
//                 }
//             }
//             catch (Exception ex)
//             {
//                 // Handle exceptions appropriately
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }

//         public async Task<responseData> SignIn(requestData rData)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 var email = rData.addInfo["EMAIL"].ToString();
//                 var password = rData.addInfo["PASSWORD"].ToString();

//                 // Check if the user exists and the password matches
//                 var query = @"SELECT * FROM mydb.signup WHERE EMAIL=@EMAIL AND PASSWORD=@PASSWORD";
//                 MySqlParameter[] myParam = new MySqlParameter[]
//                 {
//                     new MySqlParameter("@EMAIL", email),
//                     new MySqlParameter("@PASSWORD", password)
//                 };
//                 var dbData = ds.executeSQL(query, myParam);
//                 if (dbData[0].Any())
//                 {
//                     resData.rData["rMessage"] = "Signin Successful";
//                 }
//                 else
//                 {
//                     resData.rData["rMessage"] = "Invalid email or password";
//                 }
//             }
//             catch (Exception ex)
//             {
//                 // Handle exceptions appropriately
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }

//         public async Task<responseData> DeleteAccount(requestData rData)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 var userId = rData.addInfo["user_id"].ToString();

//                 // Delete user account
//                 var deleteQuery = @"DELETE FROM mydb.signup WHERE user_id=@user_id";
//                 MySqlParameter[] deleteParams = new MySqlParameter[]
//                 {
//                     new MySqlParameter("@user_id", userId)
//                 };
//                 var deleteResult = ds.executeSQL(deleteQuery, deleteParams);
//                 resData.rData["rMessage"] = "Account deleted successfully";
//             }
//             catch (Exception ex)
//             {
//                 // Handle exceptions appropriately
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }

//         public async Task<responseData> GenerateOTP(string email)
//         {
//             responseData resData = new responseData();
//              try
//             {
//                 // Generate a random OTP
//                 Random random = new Random();
//                 int otp = random.Next(100000, 999999);

//                 // Store the OTP with the email
//                 otpStorage[email] = otp;

//                 // Send the OTP to the user's email address
//                 await SendOTPEmail(email, otp);

//                 resData.rData["rMessage"] = $"OTP generated successfully and sent to {email}";
//             }
//             catch (Exception ex)
//             {
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }
//      private async Task SendOTPEmail(string email, int otp)
// {
//     try
//     {
//         string senderEmail = "jhasumi2000@gmail.com"; // Your Gmail address
//         string senderPassword = "vami czfo yhis ykpr"; // Use your app-specific password for Gmail

//         MailMessage mail = new MailMessage();
//         SmtpClient smtpServer = new SmtpClient("smtp.gmail.com");

//         // Configure email message
//         mail.From = new MailAddress(senderEmail);
//         mail.To.Add(email);
//         mail.Subject = "OTP for Password Reset";
//         mail.Body = $"Your OTP for password reset is: {otp}";

//         // Configure SMTP server
//         smtpServer.Port = 587; // Gmail SMTP port for TLS/STARTTLS
//         smtpServer.Credentials = new NetworkCredential(senderEmail, senderPassword);

//         // Enable SSL/TLS
//         smtpServer.EnableSsl = true;

//         // Send email asynchronously
//         await smtpServer.SendMailAsync(mail);
//     }
//     catch (Exception ex)
//     {
//         throw new Exception("Error sending email: " + ex.Message);
//     }
// }
//         public async Task<responseData> VerifyOTP(string email, int otp)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 // Verify the OTP
//                 if (otpStorage.ContainsKey(email) && otpStorage[email] == otp)
//                 {
//                     otpStorage.Remove(email);
//                     resData.rData["rMessage"] = "OTP verified successfully";
//                 }
//                 else
//                 {
//                     resData.rData["rMessage"] = "Invalid OTP";
//                 }
//             }
//             catch (Exception ex)
//             {
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }

//         public async Task<responseData> HandleAuthentication(requestData rData)
//         {
//             var action = rData.addInfo["action"].ToString();
//             var email = rData.addInfo["EMAIL"].ToString();

//             if (action == "signup")
//             {
//                 return await SignUp(rData);
//             }
//             else if (action == "signin")
//             {
//                 return await SignIn(rData);
//             }
//             else if (action == "delete")
//             {
//                 return await DeleteAccount(rData);
//             }
//             else if (action == "forgotpassword")
//             {
//                 return await GenerateOTP(email);
//             }
//             else if (action == "verifyotp")
//             {
//                 int otp = int.Parse(rData.addInfo["OTP"].ToString());
//                 return await VerifyOTP(email, otp);
//             }
//             else
//             {
//                 return new responseData
//                 {
//                     rData = new Dictionary<string, object>
//                     {
//                         ["rMessage"] = "Invalid action"
//                     }
//                 };
//             }
//         }
//     }
// }

// using System;
// using System.Collections.Generic;
// using System.Linq;
// using System.Threading.Tasks;
// using MySql.Data.MySqlClient;
// using System.Text.Json;
// using System.Net;
// using System.Net.Mail;

// namespace COMMON_PROJECT_STRUCTURE_API.services
// {
//     public class Authentication
//     {
//         private readonly dbServices ds = new dbServices();
//         private readonly Dictionary<string, int> otpStorage = new Dictionary<string, int>();

//         public async Task<responseData> SignUp(requestData rData)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 var email = rData.addInfo["EMAIL"].ToString();
//                 var password = rData.addInfo["PASSWORD"].ToString();

//                 // Check if the email already exists
//                 var query = @"SELECT * FROM mydb.signup WHERE EMAIL=@EMAIL";
//                 MySqlParameter[] myParam = new MySqlParameter[]
//                 {
//                     new MySqlParameter("@EMAIL", email)
//                 };
//                 var dbData = ds.executeSQL(query, myParam);
//                 if (dbData[0].Any())
//                 {
//                     resData.rData["rMessage"] = "Email already exists";
//                 }
//                 else
//                 {
//                     // Insert new user
//                     var insertQuery = @"INSERT INTO mydb.signup (EMAIL, PASSWORD) VALUES (@EMAIL, @PASSWORD)";
//                     MySqlParameter[] insertParams = new MySqlParameter[]
//                     {
//                         new MySqlParameter("@EMAIL", email),
//                         new MySqlParameter("@PASSWORD", password)
//                     };
//                     var insertResult = ds.executeSQL(insertQuery, insertParams);
//                     resData.rData["rMessage"] = "Signup Successful";
//                 }
//             }
//             catch (Exception ex)
//             {
//                 // Handle exceptions appropriately
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }

//         public async Task<responseData> SignIn(requestData rData)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 var email = rData.addInfo["EMAIL"].ToString();
//                 var password = rData.addInfo["PASSWORD"].ToString();

//                 // Check if the user exists and the password matches
//                 var query = @"SELECT * FROM mydb.signup WHERE EMAIL=@EMAIL AND PASSWORD=@PASSWORD";
//                 MySqlParameter[] myParam = new MySqlParameter[]
//                 {
//                     new MySqlParameter("@EMAIL", email),
//                     new MySqlParameter("@PASSWORD", password)
//                 };
//                 var dbData = ds.executeSQL(query, myParam);
//                 if (dbData[0].Any())
//                 {
//                     resData.rData["rMessage"] = "Signin Successful";
//                 }
//                 else
//                 {
//                     resData.rData["rMessage"] = "Invalid email or password";
//                 }
//             }
//             catch (Exception ex)
//             {
//                 // Handle exceptions appropriately
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }

//         public async Task<responseData> DeleteAccount(requestData rData)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 var userId = rData.addInfo["user_id"].ToString();

//                 // Delete user account
//                 var deleteQuery = @"DELETE FROM mydb.signup WHERE user_id=@user_id";
//                 MySqlParameter[] deleteParams = new MySqlParameter[]
//                 {
//                     new MySqlParameter("@user_id", userId)
//                 };
//                 var deleteResult = ds.executeSQL(deleteQuery, deleteParams);
//                 resData.rData["rMessage"] = "Account deleted successfully";
//             }
//             catch (Exception ex)
//             {
//                 // Handle exceptions appropriately
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }

//         public async Task<responseData> GenerateOTP(string email)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 // Generate a random OTP
//                 Random random = new Random();
//                 int otp = random.Next(100000, 999999);

//                 // Store the OTP with the email
//                 otpStorage[email] = otp;

//                 // Send the OTP to the user's email address
//                 await SendOTPEmail(email, otp);

//                 resData.rData["rMessage"] = $"OTP generated successfully and sent to {email}";
//             }
//             catch (Exception ex)
//             {
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }
//         private async Task SendOTPEmail(string email, int otp)
//         {
//             try
//             {
//                 string senderEmail = "jhasumi2000@gmail.com"; // Your Gmail address
//                 string senderPassword = "vami czfo yhis ykpr"; // Use your app-specific password for Gmail

//                 MailMessage mail = new MailMessage();
//                 SmtpClient smtpServer = new SmtpClient("smtp.gmail.com");

//                 // Configure email message
//                 mail.From = new MailAddress(senderEmail);
//                 mail.To.Add(email);
//                 mail.Subject = "OTP for Password Reset";
//                 mail.Body = $"Your OTP for password reset is: {otp}";

//                 // Configure SMTP server
//                 smtpServer.Port = 587; // Gmail SMTP port for TLS/STARTTLS
//                 smtpServer.Credentials = new NetworkCredential(senderEmail, senderPassword);

//                 // Enable SSL/TLS
//                 smtpServer.EnableSsl = true;

//                 // Send email asynchronously
//                 await smtpServer.SendMailAsync(mail);
//             }
//             catch (Exception ex)
//             {
//                 throw new Exception("Error sending email: " + ex.Message);
//             }
//         }
//         public async Task<responseData> VerifyOTP(string email, int otp)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 // Verify the OTP
//                 if (otpStorage.ContainsKey(email) && otpStorage[email] == otp)
//                 {
//                     otpStorage.Remove(email);
//                     resData.rData["rMessage"] = "OTP verified successfully";
//                 }
//                 else
//                 {
//                     resData.rData["rMessage"] = "Invalid OTP";
//                 }
//             }
//             catch (Exception ex)
//             {
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }
//         public async Task<responseData> UpdatePassword(requestData rData)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 var email = rData.addInfo["EMAIL"].ToString();
//                 var otp = int.Parse(rData.addInfo["OTP"].ToString());
//                 var newPassword = rData.addInfo["NEW_PASSWORD"].ToString();
//                 var confirmPassword = rData.addInfo["CONFIRM_PASSWORD"].ToString();

//                 // Check if new password and confirm password match
//                 if (newPassword != confirmPassword)
//                 {
//                     resData.rData["rMessage"] = "New password and confirm password do not match.";
//                     return resData;
//                 }

//                 // Verify OTP
//                 if (otpStorage.ContainsKey(email) && otpStorage[email] == otp)
//                 {
//                     otpStorage.Remove(email);

//                     // Update the password
//                     var updateQuery = @"UPDATE mydb.signup SET PASSWORD=@PASSWORD WHERE EMAIL=@EMAIL";
//                     MySqlParameter[] updateParams = new MySqlParameter[]
//                     {
//                 new MySqlParameter("@EMAIL", email),
//                 new MySqlParameter("@PASSWORD", newPassword)
//                     };
//                     ds.executeSQL(updateQuery, updateParams);

//                     resData.rData["rMessage"] = "Password updated successfully.";
//                 }
//                 else
//                 {
//                     resData.rData["rMessage"] = "Invalid OTP.";
//                 }
//             }
//             catch (Exception ex)
//             {
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }


//         public async Task<responseData> Logout(requestData rData)
//         {
//             responseData resData = new responseData();
//             try
//             {
//                 var token = rData.addInfo["TOKEN"].ToString();

//                 // Assuming you have a method to invalidate the token
//                 var result = InvalidateToken(token);
//                 if (result)
//                 {
//                     resData.rData["rMessage"] = "Logout successful";
//                 }
//                 else
//                 {
//                     resData.rData["rMessage"] = "Failed to logout";
//                 }
//             }
//             catch (Exception ex)
//             {
//                 resData.rData["rMessage"] = "Error: " + ex.Message;
//             }
//             return resData;
//         }

//         private bool InvalidateToken(string token)
//         {
//             // Implement your token invalidation logic here.
//             // For example, you might store invalidated tokens in a blacklist.
//             return true; // Return true if token is invalidated successfully.
//         }

//         public async Task<responseData> HandleAuthentication(requestData rData)
//         {
//             var action = rData.addInfo["action"].ToString();
//             var email = rData.addInfo["EMAIL"].ToString();

//             if (action == "signup")
//             {
//                 return await SignUp(rData);
//             }
//             else if (action == "signin")
//             {
//                 return await SignIn(rData);
//             }
//             else if (action == "delete")
//             {
//                 return await DeleteAccount(rData);
//             }
//             else if (action == "forgotpassword")
//             {
//                 return await GenerateOTP(email);
//             }
//             else if (action == "verifyotp")
//             {
//                 int otp = int.Parse(rData.addInfo["OTP"].ToString());
//                 return await VerifyOTP(email, otp);
//             }
//             else if (action == "updatepassword")
//             {
//                 return await UpdatePassword(rData);
//             }
//             else if (action == "logout")
//             {
//                 return await Logout(rData);
//             }
//             else
//             {
//                 return new responseData
//                 {
//                     rData = new Dictionary<string, object>
//                     {
//                         ["rMessage"] = "Invalid action"
//                     }
//                 };
//             }
//         }
//     }
// }



using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Text.Json;
using System.Net;
using System.Net.Mail;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace COMMON_PROJECT_STRUCTURE_API.services
{
    public class Authentication
    {
        private readonly dbServices ds = new dbServices();
        private readonly Dictionary<string, int> otpStorage = new Dictionary<string, int>();
        private readonly string secretKey = "vami czfo yhis ykpr"; // Define your secret key for JWT

        // Method to handle user signup
        public async Task<responseData> SignUp(requestData rData)
        {
            responseData resData = new responseData();
            try
            {
                var email = rData.addInfo["EMAIL"].ToString();
                var password = rData.addInfo["PASSWORD"].ToString();

                // Check if the email already exists
                var query = @"SELECT * FROM mydb.signup WHERE EMAIL=@EMAIL";
                MySqlParameter[] myParam = new MySqlParameter[]
                {
                    new MySqlParameter("@EMAIL", email)
                };
                var dbData = ds.executeSQL(query, myParam);
                if (dbData[0].Any())
                {
                    resData.rData["rMessage"] = "Email already exists";
                }
                else
                {
                    // Insert new user
                    var insertQuery = @"INSERT INTO mydb.signup (EMAIL, PASSWORD) VALUES (@EMAIL, @PASSWORD)";
                    MySqlParameter[] insertParams = new MySqlParameter[]
                    {
                        new MySqlParameter("@EMAIL", email),
                        new MySqlParameter("@PASSWORD", password)
                    };
                    var insertResult = ds.executeSQL(insertQuery, insertParams);
                    resData.rData["rMessage"] = "Signup Successful";
                }
            }
            catch (Exception ex)
            {
                resData.rData["rMessage"] = "Error: " + ex.Message;
            }
            return resData;
        }

        // Method to handle user signin and generate JWT token
        public async Task<responseData> SignIn(requestData rData)
        {
            responseData resData = new responseData();
            try
            {
                var email = rData.addInfo["EMAIL"].ToString();
                var password = rData.addInfo["PASSWORD"].ToString();

                // Check if the user exists and the password matches
                var query = @"SELECT * FROM mydb.signup WHERE EMAIL=@EMAIL AND PASSWORD=@PASSWORD";
                MySqlParameter[] myParam = new MySqlParameter[]
                {
                    new MySqlParameter("@EMAIL", email),
                    new MySqlParameter("@PASSWORD", password)
                };
                var dbData = ds.executeSQL(query, myParam);
                if (dbData[0].Any())
                {
                    // Generate JWT token and return it
                    var token = GenerateToken(email);
                    resData.rData["rMessage"] = "Signin Successful";
                    resData.rData["TOKEN"] = token;
                }
                else
                {
                    resData.rData["rMessage"] = "Invalid email or password";
                }
            }
            catch (Exception ex)
            {
                resData.rData["rMessage"] = "Error: " + ex.Message;
            }
            return resData;
        }

        // Method to generate JWT token
        private string GenerateToken(string email)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(secretKey);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Email, email)
                }),
                Expires = DateTime.UtcNow.AddHours(1), // Token expires in 1 hour
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        // Method to handle user logout

        public async Task<responseData> Logout(requestData rData)
        {
            responseData resData = new responseData();
            try
            {
                var token = rData.addInfo["TOKEN"].ToString();
                if (string.IsNullOrEmpty(token))
                {
                    throw new ArgumentException("Token is missing");
                }

                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(secretKey);

                // Validate the JWT token
                try
                {
                    tokenHandler.ValidateToken(token, new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(key),
                        ValidateIssuer = false,
                        ValidateAudience = false,
                        ValidateLifetime = true,
                        ClockSkew = TimeSpan.Zero
                    }, out SecurityToken validatedToken);

                    // Token is valid
                    resData.rData["rMessage"] = "Logout successful";
                }
                catch (Exception ex)
                {
                    // Token is invalid or expired
                    resData.rData["rMessage"] = "Invalid or expired token";
                    Console.WriteLine($"Exception occurred while validating token: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                // General error handling
                resData.rData["rMessage"] = "Error: " + ex.Message;
                Console.WriteLine($"Exception occurred in Logout method: {ex.Message}");
            }
            return resData;
        }


        // Method to delete user account
        public async Task<responseData> DeleteAccount(requestData rData)
        {
            responseData resData = new responseData();
            try
            {
                var userId = rData.addInfo["user_id"].ToString();

                // Delete user account
                var deleteQuery = @"DELETE FROM mydb.signup WHERE user_id=@user_id";
                MySqlParameter[] deleteParams = new MySqlParameter[]
                {
                    new MySqlParameter("@user_id", userId)
                };
                var deleteResult = ds.executeSQL(deleteQuery, deleteParams);
                resData.rData["rMessage"] = "Account deleted successfully";
            }
            catch (Exception ex)
            {
                resData.rData["rMessage"] = "Error: " + ex.Message;
            }
            return resData;
        }

        // Method to generate OTP for password reset
        public async Task<responseData> GenerateOTP(string email)
        {
            responseData resData = new responseData();
            try
            {
                // Generate a random OTP
                Random random = new Random();
                int otp = random.Next(100000, 999999);

                // Store the OTP with the email
                otpStorage[email] = otp;

                // Send the OTP to the user's email address
                await SendOTPEmail(email, otp);

                resData.rData["rMessage"] = $"OTP generated successfully and sent to {email}";
            }
            catch (Exception ex)
            {
                resData.rData["rMessage"] = "Error: " + ex.Message;
            }
            return resData;
        }

        // Method to send OTP email
        private async Task SendOTPEmail(string email, int otp)
        {
            try
            {
                string senderEmail = "jhasumi2000@gmail.com"; // Your Gmail address
                string senderPassword = "vami czfo yhis ykpr"; // Use your app-specific password for Gmail

                MailMessage mail = new MailMessage();
                SmtpClient smtpServer = new SmtpClient("smtp.gmail.com");

                // Configure email message
                mail.From = new MailAddress(senderEmail);
                mail.To.Add(email);
                mail.Subject = "OTP for Password Reset";
                mail.Body = $"Your OTP for password reset is: {otp}";

                // Configure SMTP server
                smtpServer.Port = 587; // Gmail SMTP port for TLS/STARTTLS
                smtpServer.Credentials = new NetworkCredential(senderEmail, senderPassword);

                // Enable SSL/TLS
                smtpServer.EnableSsl = true;

                // Send email asynchronously
                await smtpServer.SendMailAsync(mail);
            }
            catch (Exception ex)
            {
                throw new Exception("Error sending email: " + ex.Message);
            }
        }

        // Method to verify OTP for password reset
        public async Task<responseData> VerifyOTP(string email, int otp)
        {
            responseData resData = new responseData();
            try
            {
                // Verify the OTP
                if (otpStorage.ContainsKey(email) && otpStorage[email] == otp)
                {
                    otpStorage.Remove(email);
                    resData.rData["rMessage"] = "OTP verified successfully";
                }
                else
                {
                    resData.rData["rMessage"] = "Invalid OTP";
                }
            }
            catch (Exception ex)
            {
                resData.rData["rMessage"] = "Error: " + ex.Message;
            }
            return resData;
        }

        // Method to update user password
        public async Task<responseData> UpdatePassword(requestData rData)
        {
            responseData resData = new responseData();
            try
            {
                var email = rData.addInfo["EMAIL"].ToString();
                var otp = int.Parse(rData.addInfo["OTP"].ToString());
                var newPassword = rData.addInfo["NEW_PASSWORD"].ToString();
                var confirmPassword = rData.addInfo["CONFIRM_PASSWORD"].ToString();

                // Check if new password and confirm password match
                if (newPassword != confirmPassword)
                {
                    resData.rData["rMessage"] = "New password and confirm password do not match.";
                    return resData;
                }

                // Verify OTP
                if (otpStorage.ContainsKey(email) && otpStorage[email] == otp)
                {
                    otpStorage.Remove(email);

                    // Update the password
                    var updateQuery = @"UPDATE mydb.signup SET PASSWORD=@PASSWORD WHERE EMAIL=@EMAIL";
                    MySqlParameter[] updateParams = new MySqlParameter[]
                    {
                        new MySqlParameter("@EMAIL", email),
                        new MySqlParameter("@PASSWORD", newPassword)
                    };
                    ds.executeSQL(updateQuery, updateParams);

                    resData.rData["rMessage"] = "Password updated successfully.";
                }
                else
                {
                    resData.rData["rMessage"] = "Invalid OTP.";
                }
            }
            catch (Exception ex)
            {
                resData.rData["rMessage"] = "Error: " + ex.Message;
            }
            return resData;
        }

        // Method to handle different authentication actions
        public async Task<responseData> HandleAuthentication(requestData rData)
        {
            var action = rData.addInfo["action"].ToString();
            var email = rData.addInfo["EMAIL"].ToString();

            if (action == "signup")
            {
                return await SignUp(rData);
            }
            else if (action == "signin")
            {
                return await SignIn(rData);
            }
            else if (action == "delete")
            {
                return await DeleteAccount(rData);
            }
            else if (action == "forgotpassword")
            {
                return await GenerateOTP(email);
            }
            else if (action == "verifyotp")
            {
                int otp = int.Parse(rData.addInfo["OTP"].ToString());
                return await VerifyOTP(email, otp);
            }
            else if (action == "updatepassword")
            {
                return await UpdatePassword(rData);
            }
            else if (action == "logout")
            {
                var token = rData.addInfo["TOKEN"].ToString();
                return await Logout(rData);
            }
            else
            {
                return new responseData
                {
                    rData = new Dictionary<string, object>
                    {
                        ["rMessage"] = "Invalid action"
                    }
                };
            }
        }
    }
}





